divisible(int x int Y ){
while (x>=y){
  x=x-y
}
if (x=0) then{

else ()
}
 if X = 2 (def draw_Head_shoulders(frame):
# cascade_path = "HS.xml"
cascade_path = "haarcascade_profileface.xml"
cascade = cv2.CascadeClassifier(cascade_path)
frame = imutils.resize(frame, height=300)
gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
start = time.time()
faces = cascade.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(10, 10),
    flags=0
)
end = time.time()
total_time_taken = end - start
print(total_time_taken)
for (x, y, w, h) in faces:
    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
cv2.imshow("face and Shoulders", frame)
key = cv2.waitKey(1)
# construct the argument parse and parse the arguments
# ap = argparse.ArgumentParser()
# ap.add_argument("-i", "--images", required=True, help="path to images directory")
# args = vars(ap.parse_args())

# initialize the HOG descriptor/person detector
hog = cv2.HOGDescriptor()
hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
# for imagePath in paths.list_images(args["images"]):
# load the image and resize it to (1) reduce detection time
# and (2) improve detection accuracy
fgbg = cv2.createBackgroundSubtractorMOG2()
camera = cv2.VideoCapture(sys.argv[1])
while True:
grabbed, frame = camera.read()
if not grabbed:
    break
image = imutils.resize(frame, width=min(400, frame.shape[1]))
orig = image.copy()
start = time.time()
fgbg.apply(image)
# detect people in the image
(rects, weights) = hog.detectMultiScale(image, winStride=(4, 4),
                                        padding=(16, 16), scale=1.06)
if type(rects) is not tuple:
    cropped = image[rects[0][1]:rects[0][1] + rects[0]
                    [3], rects[0][0]:rects[0][0] + rects[0][2]]
    draw_Head_shoulders(cropped)
    # print(cropped)
# draw the original bounding boxes
# print(rects)
for (x, y, w, h) in rects:
    cv2.rectangle(orig, (x, y), (x + w, y + h), (0, 0, 255), 2)
end = time.time()
totalTimeTaken = end - start
# print(totalTimeTaken)
# apply non-maxima suppression to the bounding boxes using a
# fairly large overlap threshold to try to maintain overlapping
# boxes that are still people
rects = np.array([[x, y, x + w, y + h] for (x, y, w, h) in rects])
pick = non_max_suppression(rects, probs=None, overlapThresh=0.65)

# draw the final bounding boxes
for (xA, yA, xB, yB) in pick:
    cv2.rectangle(image, (xA, yA), (xB, yB), (0, 255, 0), 2)

# show some information on the number of bounding boxes
# print("[INFO] {}: {} original boxes, {} after suppression".format(filename, len(rects), len(pick)))

# show the output images
# cv2.imshow("Before NMS", orig)
cv2.imshow("window", image)
key = cv2.waitKey(1) & 0xFF
if key == ord("q"):
    break
camera.release()
cv2.destroyAllWindows())
else()
class Trigger(object):
    def __init__(self, trigger_data=None, request=None, response=None, _type='text', enable=True):
        if trigger_data:
            self.id = trigger_data['id']
            self.request = trigger_data['request']
            self.response = trigger_data['response']
            self.type = Type(trigger_data['type'])
            self.enable = trigger_data['enable']
        else:
            self.id = None
            self.request = request.lower()
            self.response = response
            self.type = Type(_type)
            self.enable = enable

    def save(self):
        if self.id:
            db.query(
                "UPDATE `triggers` SET `request` = %s, `response` = %s, `type` = %s, `enable` = %s WHERE `id` = %s",
                (self.request, self.response, str(self.type), self.enable, self.id)
            )
        else:
            db.query(
                "INSERT INTO `triggers` (`request`, `response`, `type`) VALUES (%s, %s, %s)",
                (self.request, self.response, str(self.type))
            )

            self.id = db.query(
                "SELECT `id` FROM `triggers` WHERE `request` = %s ORDER BY `id` DESC LIMIT 1",
                self.request, fetch=True
            )['id']

    @staticmethod
    def get_by_request(request):
        result = db.query(
            "SELECT * FROM `triggers` WHERE `enable` = True and `request` = %s",
            request, fetch=True, as_list=True
        )

        triggers = list(map(Trigger, result))
        return triggers

    @staticmethod
    def get_by_id(_id):
        result = db.query(
            "SELECT * FROM `triggers` WHERE `enable` = True and `id` = %s",
            _id, fetch=True
        )

        if result:
            return Trigger(result)
        else:
            return None

    @staticmethod
    def get_all_enabled():
        result = db.query(
            "SELECT * FROM `triggers` WHERE `enable` = True", fetch=True, as_list=True
        )

        triggers = list(map(Trigger, result))
        Loop, {
            KeyWait, LButton, D
            PixelSearch, AimPixelX, AimPixelY, NearAimScanL, NearAimScanT, NearAimScanR, NearAimScanB, EMCol, ColVn, Fast RGB
            if (!ErrorLevel=0) {
            loop, 10 {
            PixelSearch, AimPixelX, AimPixelY, ScanL, ScanT, ScanR, ScanB, EMCol, ColVn, Fast RGB
            AimX := AimPixelX - ZeroX
            AimY := AimPixelY - ZeroY
            DirX := -1
            DirY := -1
            If ( AimX > 0 ) {
            DirX := 1
            }
            If ( AimY > 0 ) {
            DirY := 1
            }
            AimOffsetX := AimX * DirX
            AimOffsetY := AimY * DirY
            MoveX := Floor(( AimOffsetX ** ( 1 / 2 ))) * DirX
            MoveY := Floor(( AimOffsetY ** ( 1 / 2 ))) * DirY
            DllCall("mouse_event", uint, 1, int, MoveX * 1.5, int, MoveY, uint, 0, int, 0)
            }
            }
            }
            
            Pause:: pause
            return:
            goto, init
            
            info:
            msgbox, 0, %version%, Made by Ult.Devs edited by Logi @ slut.io`nFortnite must be running in borderless windowed mode.`nPress pause key to pause this program.`nLeft click automatically aims down target near the center of the screen.`nRecommended for near distance(~15m) and full-auto weapons.
            return
)}